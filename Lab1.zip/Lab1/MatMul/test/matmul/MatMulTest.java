/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matmul;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author skhan.bscs13seecs
 */
public class MatMulTest {
    
    public MatMulTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of multiplication method, of class MatMul.
     */
    @Test
    public void testMultiplication() {
        int[][] matrix1 = new int[3][4];
        int[][] matrix2 = new int[4][4];

         matrix1[0][0] = 0;
        matrix1[0][1] = 1;
        matrix1[0][2] = 2;
        matrix1[0][3] = 3;
        matrix1[1][0] = 0;
        matrix1[1][1] = 1;
        matrix1[1][2] = 2;
        matrix1[1][3] = 3;
        matrix1[2][0] = 0;
        matrix1[2][1] = 1;
        matrix1[2][2] = 2;
        matrix1[2][3] = 3;

        matrix2[0][0] = 0;
        matrix2[0][1] = 1;
        matrix2[0][2] = 2;
        matrix2[0][3] = 3;
        matrix2[1][0] = 0;
        matrix2[1][1] = 1;
        matrix2[1][2] = 2;
        matrix2[1][3] = 3;
        matrix2[2][0] = 0;
        matrix2[2][1] = 1;
        matrix2[2][2] = 2;
        matrix2[2][3] = 3;
        matrix2[3][0] = 0;
        matrix2[3][1] = 1;
        matrix2[3][2] = 2;
        matrix2[3][3] = 3;
        assertArrayEquals(new int[][]{{0,6,12,18},{0,6,12,18},{0,6,12,18}},MatMul.multiplication(matrix1,matrix2)); //Tests to see if the
        //hard-coded matrices multiply to give the correct value.
        
        fail("Something is wrong with multiplication method.");
    }

    /**
     * Test of displayAnswer method, of class MatMul.
     */
    @Test
    public void testDisplayAnswer() {
        //nothing to test in this method.
    }

    /**
     * Test of main method, of class MatMul.
     */
    @Test
    public void testMain() {
        //did not test this method.
    }
    
}
