package matmul;
import java.util.Scanner;
/**
 *
 * @author skhan.bscs13seecs
 */
public class MatMul {
    
    //Simple function for iterative matrix multiplication.
    public static int[][] multiplication (int matrix1[][], int matrix2[][]){
            
        int dimensionX = matrix1.length;
        int dimensionY = matrix1[0].length;
        int dimensionZ = matrix2[0].length;
        
        int[][] answer = new int[dimensionX][dimensionZ];
        for (int i = 0; i<dimensionX; i++)
            for (int j = 0; j<dimensionZ; j++) {
                int sum = 0;
                for (int k = 0; k < dimensionY; k++)
                    sum = sum + (matrix1[i][k] * matrix2[k][j]);
                answer[i][j] = sum;
            }
        return answer;
    }
    
    //function to display the answer in matrix form.
    public static void displayAnswer (int answer[][])
    {
        int dimensionX = answer.length;
        int dimensionY = answer[0].length;
        System.out.print("\n");
        for (int i = 0; i<dimensionX; i++) {
            System.out.print("[");
            for (int j = 0; j < dimensionY; j++) {
                if (j==dimensionY-1)
                    System.out.print(answer[i][j]);
                else
                    System.out.print(answer[i][j] + ",");
            }
            System.out.print("]\n");
        }
        System.out.print("\n");
    }
    
    public static void main (String args[]) {
        
        //hard-coded matrices to be multiplied.
        int[][] matrix1 = new int[3][4];
        int[][] matrix2 = new int[4][4];

        matrix1[0][0] = 0;
        matrix1[0][1] = 1;
        matrix1[0][2] = 2;
        matrix1[0][3] = 3;
        matrix1[1][0] = 0;
        matrix1[1][1] = 1;
        matrix1[1][2] = 2;
        matrix1[1][3] = 3;
        matrix1[2][0] = 0;
        matrix1[2][1] = 1;
        matrix1[2][2] = 2;
        matrix1[2][3] = 3;

        matrix2[0][0] = 0;
        matrix2[0][1] = 1;
        matrix2[0][2] = 2;
        matrix2[0][3] = 3;
        matrix2[1][0] = 0;
        matrix2[1][1] = 1;
        matrix2[1][2] = 2;
        matrix2[1][3] = 3;
        matrix2[2][0] = 0;
        matrix2[2][1] = 1;
        matrix2[2][2] = 2;
        matrix2[2][3] = 3;
        matrix2[3][0] = 0;
        matrix2[3][1] = 1;
        matrix2[3][2] = 2;
        matrix2[3][3] = 3;


        displayAnswer(multiplication(matrix1,matrix2));
    }
    
}
